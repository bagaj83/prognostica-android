# Prognostica ProGuard / R8 Rules
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

-keep class kz.prognostika.app.model.** { *; }
-keep class kz.prognostika.app.data.** { *; }
