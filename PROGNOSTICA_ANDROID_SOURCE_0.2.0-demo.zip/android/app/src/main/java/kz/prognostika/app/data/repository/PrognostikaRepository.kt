package kz.prognostika.app.data.repository

import kz.prognostika.app.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Репозиторий данных системы «Прогностика»
 * Реализует паттерн единого источника истины (Single Source of Truth).
 * В текущей MVP-версии поставляет встроенные тестовые данные пилотного контура,
 * в промышленной версии подключает REST/gRPC API серверной части.
 */
class PrognostikaRepository {

    val metadata = SystemMetadata()

    val objects: List<HydroObject> = listOf(
        HydroObject(
            id = "petropavl-gauge",
            name = "Гидропост Петропавловск",
            type = "Гидрологический пост",
            category = "Гидрологические посты",
            status = RiskStatus.ATTENTION,
            keyMetric = "Уровень воды",
            keyValue = "742 см",
            trend = "+8 см/сут",
            forecast = "В DEMO-сценарии ожидается плавное повышение уровня в ближайшие двое суток до 758 см.",
            recommendation = "Продолжить учащённый контроль DEMO-показателей и проверить связанные объекты пилотного контура.",
            location = LocationPoint(
                name = "г. Петропавловск, створ р. Есиль",
                xPercent = 52f,
                yPercent = 48f,
                coordinatesText = "Условный створ 54.87° N, 69.15° E (DEMO)"
            ),
            hazardLevel = "Повышенный (рост притока)",
            probability = "Средняя",
            consequences = "Умеренные",
            parameters = listOf(
                ObjectParameter("Уровень воды над нулём поста", "742 см", "см", "DEMO hydropost", "warning", "09:00"),
                ObjectParameter("Изменение за последние сутки", "+8 см", "см/сут", "DEMO calculation", "warning", "09:00"),
                ObjectParameter("Предупредительный уровень", "750 см", "см", "Технический регламент DEMO", "normal"),
                ObjectParameter("Критический уровень (выход в пойму)", "800 см", "см", "Технический регламент DEMO", "normal"),
                ObjectParameter("Температура воды", "+14.2 °C", "°C", "DEMO hydropost sensor", "normal", "08:45"),
                ObjectParameter("Мутность потока", "18 NTU", "NTU", "DEMO sensor", "normal", "08:30")
            ),
            evidence = EvidenceStep(
                source = "DEMO hydropost (створ Петропавловск)",
                data = "Условный временной ряд уровня воды с интервалом 3 часа",
                calculation = "DEMO trend calculation (скользящая линейная аппроксимация притока)",
                risk = "Внимание (до предупредительного уровня остаётся 8 см)",
                recommendation = "Усилить наблюдение и оповестить дежурную смену насосных станций",
                timestamp = "16.09.2026 09:00",
                modelDetails = "Гидрологическая модель склонового стока v1.2-demo"
            ),
            history = listOf(
                ObjectHistoryEntry("16.09 09:00", "Уровень достиг 742 см", "warning", "Превышена контрольная планка 740 см в рамках тестового сценария."),
                ObjectHistoryEntry("15.09 21:00", "Уровень 738 см (+4 см за 12ч)", "info", "Поступление волны попуска с верхнего бьефа."),
                ObjectHistoryEntry("15.09 09:00", "Уровень 734 см", "info", "Штатный гидрологический режим.")
            )
        ),
        HydroObject(
            id = "sergeevka-dam",
            name = "Сергеевский гидроузел",
            type = "Гидротехническое сооружение",
            category = "Гидроузлы",
            status = RiskStatus.ATTENTION,
            keyMetric = "Перелив через гребень",
            keyValue = "+42 см",
            trend = "+5 см/сут",
            forecast = "Перелив сохранится на уровне 40-50 см ещё до 72 часов.",
            recommendation = "Мониторинг пропускного тракта и оповещение районов ниже по течению.",
            location = LocationPoint(
                name = "Сергеевское водохранилище",
                xPercent = 25f,
                yPercent = 75f,
                coordinatesText = "Створ водохранилища (DEMO)"
            ),
            hazardLevel = "Повышенный сброс",
            probability = "Высокая",
            consequences = "Умеренные",
            parameters = listOf(
                ObjectParameter("Слой перелива над шандорами", "42 см", "см", "Датчик водосливной плотины", "warning", "08:30"),
                ObjectParameter("Текущий объём наполнения", "104.2%", "%", "АСУ ТП гидроузла", "warning", "08:30"),
                ObjectParameter("Расход сброса в нижний бьеф", "312 м³/с", "м³/с", "Гидрометрический расчёт", "warning", "08:00")
            ),
            evidence = EvidenceStep(
                source = "АСУ ТП Сергеевского гидроузла",
                data = "Уровень верхнего бьефа и объём аккумулированного стока",
                calculation = "Балансовая модель водохранилища Q_сбр = f(H_перелива)",
                risk = "Внимание (активный перелив вызывает повышенную нагрузку на русло ниже по течению)",
                recommendation = "Обеспечить постоянный мониторинг времени добегания волны (48-60 часов до Петропавловска)"
            )
        ),
        HydroObject(
            id = "petropavl-dam",
            name = "Петропавловский гидроузел",
            type = "Регулирующий гидроузел",
            category = "Гидроузлы",
            status = RiskStatus.NORMAL,
            keyMetric = "Сбросной расход",
            keyValue = "195 м³/с",
            trend = "Стабильно",
            forecast = "Штатный режим шандорных затворов.",
            recommendation = "Дежурный регламент, готовность к регулированию шандор.",
            location = LocationPoint(
                name = "Петропавловск, река Есиль",
                xPercent = 50f,
                yPercent = 50f,
                coordinatesText = "Створ плотины (DEMO)"
            ),
            hazardLevel = "Штатный",
            probability = "Низкая",
            consequences = "Незначительные",
            parameters = listOf(
                ObjectParameter("Уровень верхнего бьефа", "82.4 м БС", "м БС", "Датчик плотины", "normal"),
                ObjectParameter("Пропускная способность", "650 м³/с", "м³/с", "Паспорт сооружения", "normal")
            ),
            evidence = EvidenceStep(
                source = "Телеметрия гидроузла",
                data = "Открытие затворов: 3 из 6",
                calculation = "Гидравлический расчет истечения из-под щитов",
                risk = "Норма (запас пропускной способности более 60%)",
                recommendation = "Сохранять текущее положение шандоров"
            )
        ),
        HydroObject(
            id = "zarechny-dike",
            name = "Защитная дамба пос. Заречный",
            type = "Инженерная защита",
            category = "Защитные сооружения",
            status = RiskStatus.HIGH,
            keyMetric = "Запас до гребня дамбы",
            keyValue = "58 см",
            trend = "-8 см/сут запаса",
            forecast = "При росте уровня до 760 см запас снизится до 40 см.",
            recommendation = "Организовать круглосуточный патруль тела дамбы, проверить запасы мешкотары и суглинка.",
            location = LocationPoint(
                name = "п. Заречный, береговой фронт",
                xPercent = 64f,
                yPercent = 42f,
                coordinatesText = "Трасса защитной дамбы (DEMO)"
            ),
            hazardLevel = "Высокая угроза перелива",
            probability = "Высокая",
            consequences = "Тяжёлые",
            parameters = listOf(
                ObjectParameter("Отметка гребня дамбы", "800 см", "см", "Проектная документация", "normal"),
                ObjectParameter("Текущий уровень у подошвы", "742 см", "см", "Пикет №4", "warning", "09:00"),
                ObjectParameter("Остаточный сухой откос", "58 см", "см", "Расчёт запаса", "danger", "09:00"),
                ObjectParameter("Признаки фильтрации", "Не зафиксировано", "", "Визуальный осмотр", "normal", "07:30")
            ),
            evidence = EvidenceStep(
                source = "Пикетная рейка №4 и нивелирный обход",
                data = "Высота уреза воды 742 см при высоте гребня 800 см",
                calculation = "H_запаса = H_гребня - H_воды = 58 см; при ветровом нагоне 20 см запас критичен",
                risk = "Высокий риск (при снижении запаса менее 50 см требуется укладка мешков с грунтом)",
                recommendation = "Направить аварийную бригаду инженерной защиты, развернуть резервные мотопомпы"
            )
        ),
        HydroObject(
            id = "pump-station-1",
            name = "Насосная станция 1-го подъёма (Горводоканал)",
            type = "Критическая инфраструктура",
            category = "Критическая инфраструктура",
            status = RiskStatus.ATTENTION,
            keyMetric = "Запас обвалования",
            keyValue = "85 см",
            trend = "-8 см/сут",
            forecast = "Угрозы прямого затопления машинного зала на текущий момент нет.",
            recommendation = "Проверить герметизацию кабельных вводов, резервные дизель-генераторы.",
            location = LocationPoint(
                name = "Береговая зона водозабора",
                xPercent = 47f,
                yPercent = 44f,
                coordinatesText = "Водозаборное сооружение (DEMO)"
            ),
            hazardLevel = "Повышенное внимание",
            probability = "Средняя",
            consequences = "Тяжёлые",
            parameters = listOf(
                ObjectParameter("Уровень у защитной стены", "742 см", "см", "Датчик площадки", "warning"),
                ObjectParameter("Отметка порога машзала", "835 см", "см", "Паспорт объекта", "normal"),
                ObjectParameter("Работа насосных агрегатов", "3 рабочих, 1 резерв", "", "АСУ водоканала", "normal")
            ),
            evidence = EvidenceStep(
                source = "АСУ ТП Городского водоканала",
                data = "Мониторинг приямков и дренажной системы насосной станции",
                calculation = "Модель устойчивости водозабора при расчётном паводке 1% обеспеченности",
                risk = "Внимание (жизнеобеспечивающий объект города)",
                recommendation = "Провести пробный пуск откачивающих дренажных насосов"
            )
        ),
        HydroObject(
            id = "road-bypass",
            name = "Автодорога в обход Петропавловска (низменный участок)",
            type = "Транспортная инфраструктура",
            category = "Автомобильные дороги",
            status = RiskStatus.HIGH,
            keyMetric = "Уровень до бровки полотна",
            keyValue = "22 см",
            trend = "-8 см/сут",
            forecast = "Возможен перелив через дорожное полотно в течение 36-48 часов при сохранении притока.",
            recommendation = "Подготовить схему объезда, предупредить дорожные службы и полицию.",
            location = LocationPoint(
                name = "ПК 12+40 объездной трассы",
                xPercent = 68f,
                yPercent = 58f,
                coordinatesText = "Пойменный участок автодороги (DEMO)"
            ),
            hazardLevel = "Угроза перелива полотна",
            probability = "Высокая",
            consequences = "Умеренные",
            parameters = listOf(
                ObjectParameter("Высота уреза воды до дорожного полотна", "22 см", "см", "Дорожный пост", "danger"),
                ObjectParameter("Пропускная способность водопропускных труб", "85% заполнено", "", "Осмотр ДЭУ", "warning")
            ),
            evidence = EvidenceStep(
                source = "Осмотр эксплуатационной дорожной службы",
                data = "Замер расстояния от воды до дорожной одежды на ПК 12+40",
                calculation = "При подъёме воды на 25 см прогнозируется слой перелива 3-5 см",
                risk = "Высокий риск (ограничение движения легкового транспорта)",
                recommendation = "Выставить предупреждающие знаки и дорожные вешки, заготовить щебень для отсыпки"
            )
        ),
        HydroObject(
            id = "bridge-esil",
            name = "Мостовой переход через р. Есиль",
            type = "Мостовое сооружение",
            category = "Мосты",
            status = RiskStatus.NORMAL,
            keyMetric = "Подмостовой габарит",
            keyValue = "240 см",
            trend = "-8 см/сут",
            forecast = "Габарит достаточен для пропуска плавающего мусора и льдин.",
            recommendation = "Штатный мониторинг ледорезных опор и подмостового русла.",
            location = LocationPoint(
                name = "Магистральный въезд в город",
                xPercent = 55f,
                yPercent = 46f,
                coordinatesText = "Створ моста (DEMO)"
            ),
            hazardLevel = "Штатный",
            probability = "Низкая",
            consequences = "Незначительные",
            parameters = listOf(
                ObjectParameter("Подмостовой габарит до низа балок", "240 см", "см", "Датчик пролёта", "normal"),
                ObjectParameter("Скорость течения в створе", "1.8 м/с", "м/с", "УЗ-расходомер", "normal")
            ),
            evidence = EvidenceStep(
                source = "Мостовая инспекция",
                data = "Датчик подмостового габарита",
                calculation = "Запас высоты превышает нормативный минимум 1.5 м",
                risk = "Норма",
                recommendation = "Плановый осмотр опор 2 раза в сутки"
            )
        ),
        HydroObject(
            id = "subdistrict-kozhzavod",
            name = "Жилой массив Кожзавод (прибрежные улицы)",
            type = "Жилая территория",
            category = "Жилые территории",
            status = RiskStatus.HIGH,
            keyMetric = "До опасного уровня затопления",
            keyValue = "38 см",
            trend = "-8 см/сут",
            forecast = "Возможен выход грунтовых вод в подвалы и подтопление придомовых территорий нижнего яруса.",
            recommendation = "Информирование жителей береговой линии, проверка готовности пунктов временного размещения.",
            location = LocationPoint(
                name = "мкр. Кожзавод, низменная часть",
                xPercent = 40f,
                yPercent = 38f,
                coordinatesText = "Береговой жилой сектор (DEMO)"
            ),
            hazardLevel = "Угроза подтопления пониженных участков",
            probability = "Высокая",
            consequences = "Тяжёлые",
            parameters = listOf(
                ObjectParameter("Уровень воды в прибрежной канаве", "742 см", "см", "Временный пост", "warning"),
                ObjectParameter("Уровень грунтовых вод", "0.4 м от поверхности", "м", "Контрольная скважина №2", "danger"),
                ObjectParameter("Число домов в зоне возможного подтопления", "18 домов", "шт", "Паспорт территории", "warning")
            ),
            evidence = EvidenceStep(
                source = "Карта рельефа и гидропост Петропавловск",
                data = "Цифровая модель рельефа LiDAR + отметка 742 см",
                calculation = "Зона подпора при отметке 760 см затронет 6 огородов и 2 подъездные дороги",
                risk = "Высокий риск (социальная значимость, жилой сектор)",
                recommendation = "Провести подомовой обход, уточнить списки маломобильных граждан"
            )
        )
    )

    val forecastPoints: List<WaterForecastPoint> = listOf(
        WaterForecastPoint("13.09", "13 Сен", 715, false, 0, RiskStatus.NORMAL),
        WaterForecastPoint("14.09", "14 Сен", 724, false, 0, RiskStatus.NORMAL),
        WaterForecastPoint("15.09", "15 Сен", 734, false, 0, RiskStatus.NORMAL),
        WaterForecastPoint("16.09 (Факт)", "Сегодня", 742, false, 0, RiskStatus.ATTENTION),
        WaterForecastPoint("+1 сут", "17 Сен", 751, true, 8, RiskStatus.HIGH),
        WaterForecastPoint("+2 сут", "18 Сен", 758, true, 14, RiskStatus.HIGH),
        WaterForecastPoint("+3 сут", "19 Сен", 763, true, 20, RiskStatus.HIGH),
        WaterForecastPoint("+4 сут", "20 Сен", 765, true, 25, RiskStatus.HIGH),
        WaterForecastPoint("+5 сут", "21 Сен", 762, true, 30, RiskStatus.HIGH)
    )

    val alertEvents: List<AlertEvent> = listOf(
        AlertEvent(
            id = "ev-1",
            priority = RiskStatus.HIGH,
            objectId = "zarechny-dike",
            objectName = "Защитная дамба пос. Заречный",
            title = "Запас до гребня сократился до 58 см",
            description = "Рост уровня воды приблизился к опасной отметке тела дамбы. Требуется усиление патрулирования.",
            consequences = "Угроза перелива при ветровом волнении",
            time = "16.09.2026 08:30",
            action = "Направить патруль инженерной защиты и проверить запас мешкотары"
        ),
        AlertEvent(
            id = "ev-2",
            priority = RiskStatus.HIGH,
            objectId = "road-bypass",
            objectName = "Автодорога в обход Петропавловска",
            title = "Приближение воды к полотну дороги (запас 22 см)",
            description = "На ПК 12+40 водопропускные трубы работают под максимальным напором.",
            consequences = "Угроза перелива через проезжую часть через 36-48 часов",
            time = "16.09.2026 07:45",
            action = "Подготовить экипажи дорожной полиции для возможного регулирования движения"
        ),
        AlertEvent(
            id = "ev-3",
            priority = RiskStatus.ATTENTION,
            objectId = "petropavl-gauge",
            objectName = "Гидропост Петропавловск",
            title = "Уровень воды достиг 742 см (+8 см/сут)",
            description = "До предупредительного уровня 750 см остаётся 8 см.",
            consequences = "Увеличение нагрузки на гидроузлы и береговую линию",
            time = "16.09.2026 06:00",
            action = "Перевести пост на 2-часовой регламент отсчёта"
        )
    )

    private val _objectsFlow = MutableStateFlow(objects)
    val objectsFlow: StateFlow<List<HydroObject>> = _objectsFlow.asStateFlow()

    fun getAttentionObjects(): List<HydroObject> =
        objects.filter { it.status.isAttentionOrHigher }

    fun getObjectById(id: String): HydroObject? =
        objects.find { it.id == id }
}
