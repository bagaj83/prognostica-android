package kz.prognostika.app.ui.theme

import androidx.compose.ui.graphics.Color
import kz.prognostika.app.data.model.RiskStatus

// Primary Brand Colors
val BrandCyanPrimary = Color(0xFF0EA5E9)
val BrandCyanDark = Color(0xFF0369A1)
val BrandCyanLight = Color(0xFF38BDF8)

// Surface and Background Colors (Industrial Dark Theme)
val DarkBackground = Color(0xFF090D16)
val DarkSurfaceCard = Color(0xFF0F172A)
val DarkSurfaceCardBorder = Color(0xFF1E293B)
val DarkSurfaceCardHover = Color(0xFF1E293B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Risk Semantic Colors
val RiskNormalGreen = Color(0xFF10B981)
val RiskNormalBg = Color(0xFF064E3B)
val RiskNormalBorder = Color(0xFF059669)

val RiskAttentionAmber = Color(0xFFF59E0B)
val RiskAttentionBg = Color(0xFF451A03)
val RiskAttentionBorder = Color(0xFFD97706)

val RiskHighOrange = Color(0xFFF97316)
val RiskHighBg = Color(0xFF7C2D12)
val RiskHighBorder = Color(0xFFEA580C)

val RiskCriticalRed = Color(0xFFEF4444)
val RiskCriticalBg = Color(0xFF7F1D1D)
val RiskCriticalBorder = Color(0xFFDC2626)

fun getRiskColor(status: RiskStatus): Color = when (status) {
    RiskStatus.NORMAL -> RiskNormalGreen
    RiskStatus.ATTENTION -> RiskAttentionAmber
    RiskStatus.HIGH -> RiskHighOrange
    RiskStatus.CRITICAL -> RiskCriticalRed
}

fun getRiskBackgroundColor(status: RiskStatus): Color = when (status) {
    RiskStatus.NORMAL -> RiskNormalBg.copy(alpha = 0.35f)
    RiskStatus.ATTENTION -> RiskAttentionBg.copy(alpha = 0.5f)
    RiskStatus.HIGH -> RiskHighBg.copy(alpha = 0.55f)
    RiskStatus.CRITICAL -> RiskCriticalBg.copy(alpha = 0.6f)
}

fun getRiskBorderColor(status: RiskStatus): Color = when (status) {
    RiskStatus.NORMAL -> RiskNormalBorder
    RiskStatus.ATTENTION -> RiskAttentionBorder
    RiskStatus.HIGH -> RiskHighBorder
    RiskStatus.CRITICAL -> RiskCriticalBorder
}
