package kz.prognostika.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kz.prognostika.app.data.model.AlertEvent
import kz.prognostika.app.data.model.HydroObject
import kz.prognostika.app.data.model.RiskStatus
import kz.prognostika.app.data.model.SystemMetadata
import kz.prognostika.app.data.model.WaterForecastPoint
import kz.prognostika.app.data.repository.PrognostikaRepository

data class PrognostikaUiState(
    val metadata: SystemMetadata = SystemMetadata(),
    val allObjects: List<HydroObject> = emptyList(),
    val attentionObjects: List<HydroObject> = emptyList(),
    val forecastPoints: List<WaterForecastPoint> = emptyList(),
    val alertEvents: List<AlertEvent> = emptyList(),
    val selectedObject: HydroObject? = null,
    val selectedCategory: String = "Все",
    val selectedStatusFilter: RiskStatus? = null,
    val searchQuery: String = ""
)

class PrognostikaViewModel(
    private val repository: PrognostikaRepository = PrognostikaRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        PrognostikaUiState(
            metadata = repository.metadata,
            allObjects = repository.objects,
            attentionObjects = repository.getAttentionObjects(),
            forecastPoints = repository.forecastPoints,
            alertEvents = repository.alertEvents
        )
    )
    val uiState: StateFlow<PrognostikaUiState> = _uiState.asStateFlow()

    fun selectObject(id: String) {
        val obj = repository.getObjectById(id)
        _uiState.value = _uiState.value.copy(selectedObject = obj)
    }

    fun clearSelectedObject() {
        _uiState.value = _uiState.value.copy(selectedObject = null)
    }

    fun setCategoryFilter(category: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun setStatusFilter(status: RiskStatus?) {
        _uiState.value = _uiState.value.copy(selectedStatusFilter = status)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }
}
