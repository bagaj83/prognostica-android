package kz.prognostika.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kz.prognostika.app.data.model.HydroObject
import kz.prognostika.app.ui.components.RiskBadge
import kz.prognostika.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ObjectDetailScreen(
    obj: HydroObject?,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (obj == null) {
        Box(
            modifier = modifier.fillMaxSize().background(DarkBackground),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Объект не найден", color = TextSecondary)
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = obj.name,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Назад",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurfaceCard
                )
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Заголовочная сводка объекта
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceCard)
                        .border(1.5.dp, getRiskBorderColor(obj.status), RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = obj.category.uppercase(),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        RiskBadge(status = obj.status, large = true)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = obj.name,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = obj.location.name,
                        color = BrandCyanLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // 1. РАЗДЕЛ: «СОСТОЯНИЕ»
            item {
                DetailSection(title = "1. СОСТОЯНИЕ") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Ключевой показатель", color = TextSecondary, fontSize = 11.sp)
                            Text(text = obj.keyMetric, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Значение / Динамика", color = TextSecondary, fontSize = 11.sp)
                            Text(
                                text = "${obj.keyValue} (${obj.trend})",
                                color = getRiskColor(obj.status),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Уровень угрозы: ${obj.hazardLevel}",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                }
            }

            // 2. РАЗДЕЛ: «ПОКАЗАТЕЛИ»
            item {
                DetailSection(title = "2. ПОКАЗАТЕЛИ") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        obj.parameters.forEach { param ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkBackground)
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = param.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    Text(text = "Источник: ${param.source}", color = TextTertiary, fontSize = 10.sp)
                                }
                                Text(
                                    text = param.value,
                                    color = if (param.status == "danger") RiskCriticalRed else if (param.status == "warning") RiskAttentionAmber else Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 3. РАЗДЕЛ: «ПРОГНОЗ»
            item {
                DetailSection(title = "3. ПРОГНОЗ") {
                    Text(
                        text = obj.forecast,
                        color = Color.White,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            // 4. РАЗДЕЛ: «РИСК»
            item {
                DetailSection(title = "4. РИСК") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Вероятность реализации", color = TextSecondary, fontSize = 11.sp)
                            Text(text = obj.probability, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Тяжесть последствий", color = TextSecondary, fontSize = 11.sp)
                            Text(text = obj.consequences, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Оценка риска: ${obj.status.titleRu} — ${obj.status.description}",
                        color = getRiskColor(obj.status),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // 5. РАЗДЕЛ: «ОСНОВАНИЕ ОЦЕНКИ»
            item {
                DetailSection(title = "5. ОСНОВАНИЕ ОЦЕНКИ (ЦЕПОЧКА ДОКАЗАТЕЛЬСТВ)") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkBackground)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        EvidenceRow(label = "Источник данных:", value = obj.evidence.source)
                        EvidenceRow(label = "Входные данные:", value = obj.evidence.data)
                        EvidenceRow(label = "Расчетный алгоритм:", value = obj.evidence.calculation)
                        obj.evidence.modelDetails?.let {
                            EvidenceRow(label = "Модель / регламент:", value = it)
                        }
                    }
                }
            }

            // 6. РАЗДЕЛ: «РЕКОМЕНДУЕМОЕ ДЕЙСТВИЕ»
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0F233A))
                        .border(1.5.dp, BrandCyanPrimary, RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "6. РЕКОМЕНДУЕМОЕ ДЕЙСТВИЕ",
                        color = BrandCyanLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = obj.recommendation,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DetailSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, DarkSurfaceCardBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text(
            text = title,
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun EvidenceRow(label: String, value: String) {
    Column {
        Text(text = label, color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = TextPrimary, fontSize = 11.sp, lineHeight = 15.sp)
    }
}
