package kz.prognostika.app

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import kz.prognostika.app.ui.navigation.Screen
import kz.prognostika.app.ui.navigation.bottomNavItems
import kz.prognostika.app.ui.screens.*
import kz.prognostika.app.ui.theme.*
import kz.prognostika.app.ui.viewmodel.PrognostikaViewModel

@Composable
fun PrognostikaApp(
    viewModel: PrognostikaViewModel = viewModel()
) {
    val navController = rememberNavController()
    val state by viewModel.uiState.collectAsState()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val isDetailScreen = currentRoute?.startsWith("object_detail") == true

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            if (!isDetailScreen) {
                NavigationBar(
                    containerColor = DarkSurfaceCard,
                    contentColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            selected = selected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BrandCyanLight,
                                selectedTextColor = BrandCyanLight,
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary,
                                indicatorColor = BrandCyanDark.copy(alpha = 0.4f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Overview.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Screen.Overview.route) {
                OverviewScreen(
                    state = state,
                    onSelectObject = { objectId ->
                        viewModel.selectObject(objectId)
                        navController.navigate(Screen.ObjectDetail.createRoute(objectId))
                    }
                )
            }
            composable(Screen.Map.route) {
                MapScreen(
                    state = state,
                    onSelectObject = { objectId ->
                        viewModel.selectObject(objectId)
                        navController.navigate(Screen.ObjectDetail.createRoute(objectId))
                    }
                )
            }
            composable(Screen.Objects.route) {
                ObjectsScreen(
                    state = state,
                    onSelectObject = { objectId ->
                        viewModel.selectObject(objectId)
                        navController.navigate(Screen.ObjectDetail.createRoute(objectId))
                    }
                )
            }
            composable(Screen.Alerts.route) {
                AlertsScreen(
                    state = state,
                    onSelectObject = { objectId ->
                        viewModel.selectObject(objectId)
                        navController.navigate(Screen.ObjectDetail.createRoute(objectId))
                    }
                )
            }
            composable(Screen.More.route) {
                MoreScreen(state = state)
            }
            composable(Screen.ObjectDetail.route) { backStackEntry ->
                val objectId = backStackEntry.arguments?.getString("objectId")
                val obj = state.allObjects.find { it.id == objectId } ?: state.selectedObject

                ObjectDetailScreen(
                    obj = obj,
                    onBack = {
                        viewModel.clearSelectedObject()
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}
