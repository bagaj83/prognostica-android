package kz.prognostika.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kz.prognostika.app.data.model.AlertEvent
import kz.prognostika.app.ui.components.DemoHeader
import kz.prognostika.app.ui.components.RiskBadge
import kz.prognostika.app.ui.theme.*
import kz.prognostika.app.ui.viewmodel.PrognostikaUiState

@Composable
fun AlertsScreen(
    state: PrognostikaUiState,
    onSelectObject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            DemoHeader(
                title = "СОБЫТИЯ",
                subtitle = "Оперативный журнал предупреждений (${state.alertEvents.size})",
                updatedAt = state.metadata.updatedAt
            )
        }

        items(state.alertEvents) { event ->
            AlertEventCard(
                event = event,
                onClick = { onSelectObject(event.objectId) },
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
fun AlertEventCard(
    event: AlertEvent,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, getRiskBorderColor(event.priority), RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = event.time,
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            RiskBadge(status = event.priority)
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = event.title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "Объект: ${event.objectName}",
            color = BrandCyanLight,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = event.description,
            color = Color(0xFFCBD5E1),
            fontSize = 12.sp,
            lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F233A))
                .padding(8.dp)
        ) {
            Column {
                Text(
                    text = "ДЕЙСТВИЕ:",
                    color = BrandCyanLight,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = event.action,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
