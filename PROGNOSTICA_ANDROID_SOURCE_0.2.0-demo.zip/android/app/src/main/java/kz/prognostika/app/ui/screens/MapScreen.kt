package kz.prognostika.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kz.prognostika.app.data.model.HydroObject
import kz.prognostika.app.ui.components.DemoHeader
import kz.prognostika.app.ui.components.RiskBadge
import kz.prognostika.app.ui.theme.*
import kz.prognostika.app.ui.viewmodel.PrognostikaUiState

@Composable
fun MapScreen(
    state: PrognostikaUiState,
    onSelectObject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var highlightedObjectId by remember { mutableStateOf<String?>(state.attentionObjects.firstOrNull()?.id) }
    val highlightedObject = state.allObjects.find { it.id == highlightedObjectId }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        DemoHeader(
            title = "КАРТА-СХЕМА",
            subtitle = "Схема бассейна реки Есиль (DEMO)",
            updatedAt = state.metadata.updatedAt
        )

        // Интерактивная векторная схема на Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurfaceCard)
                .border(1.dp, DarkSurfaceCardBorder, RoundedCornerShape(16.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Отрисовка русла реки Есиль (S-образный изгиб)
                val riverPath = Path().apply {
                    moveTo(w * 0.15f, h * 0.85f)
                    cubicTo(
                        w * 0.35f, h * 0.70f,
                        w * 0.45f, h * 0.60f,
                        w * 0.52f, h * 0.48f
                    )
                    cubicTo(
                        w * 0.58f, h * 0.38f,
                        w * 0.65f, h * 0.30f,
                        w * 0.85f, h * 0.15f
                    )
                }

                // Внешнее русло/пойма
                drawPath(
                    path = riverPath,
                    color = Color(0x330284C7),
                    style = Stroke(width = 38f)
                )

                // Основное русло
                drawPath(
                    path = riverPath,
                    color = BrandCyanPrimary,
                    style = Stroke(width = 16f)
                )

                // Отрисовка точек объектов
                state.allObjects.forEach { obj ->
                    val cx = w * (obj.location.xPercent / 100f)
                    val cy = h * (obj.location.yPercent / 100f)
                    val isSelected = obj.id == highlightedObjectId

                    // Фоновый ореол для выбранного объекта
                    if (isSelected) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.3f),
                            radius = 22f,
                            center = Offset(cx, cy)
                        )
                    }

                    // Цвет статуса риска
                    drawCircle(
                        color = getRiskColor(obj.status),
                        radius = if (isSelected) 12f else 8f,
                        center = Offset(cx, cy)
                    )
                }
            }

            // Быстрый переключатель объектов по клику
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xCC090D16))
                    .padding(8.dp)
            ) {
                Text(text = "Легенда рисков:", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(RiskCriticalRed))
                    Text(text = "Крит. / Высокий", color = TextPrimary, fontSize = 10.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(RiskAttentionAmber))
                    Text(text = "Внимание", color = TextPrimary, fontSize = 10.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(RiskNormalGreen))
                    Text(text = "Норма", color = TextPrimary, fontSize = 10.sp)
                }
            }
        }

        // Горизонтальный список меток объектов для быстрого выбора на схеме
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.allObjects) { obj ->
                val isSelected = obj.id == highlightedObjectId
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) BrandCyanDark else DarkSurfaceCard)
                        .border(1.dp, if (isSelected) BrandCyanPrimary else DarkSurfaceCardBorder, RoundedCornerShape(8.dp))
                        .clickable { highlightedObjectId = obj.id }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = obj.name,
                        color = if (isSelected) Color.White else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Карточка выбранного объекта на схеме с переходом в детали
        highlightedObject?.let { obj ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                AttentionObjectCard(
                    obj = obj,
                    onClick = { onSelectObject(obj.id) }
                )
            }
        }
    }
}
