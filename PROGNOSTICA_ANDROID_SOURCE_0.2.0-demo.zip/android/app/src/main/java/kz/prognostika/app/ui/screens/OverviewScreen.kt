package kz.prognostika.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kz.prognostika.app.data.model.HydroObject
import kz.prognostika.app.data.model.RiskStatus
import kz.prognostika.app.ui.components.DemoHeader
import kz.prognostika.app.ui.components.MetricCard
import kz.prognostika.app.ui.components.RiskBadge
import kz.prognostika.app.ui.theme.*
import kz.prognostika.app.ui.viewmodel.PrognostikaUiState

@Composable
fun OverviewScreen(
    state: PrognostikaUiState,
    onSelectObject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Вверху — «Прогностика», дата/время и «DEMO»
        item {
            DemoHeader(
                title = "ПРОГНОСТИКА",
                subtitle = state.metadata.region,
                updatedAt = state.metadata.updatedAt
            )
        }

        // 2. Крупная карточка «Текущая обстановка» с общим уровнем риска
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkSurfaceCard)
                    .border(2.dp, getRiskBorderColor(state.metadata.overallRisk), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ТЕКУЩАЯ ОБСТАНОВКА",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Бассейн р. Есиль — г. Петропавловск",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    RiskBadge(status = state.metadata.overallRisk, large = true)
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Формирование второй волны паводка. Наблюдается умеренный рост уровней на гидропостах верхнего и среднего течения. Сооружения инженерной защиты работают в режиме повышенной готовности.",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }

        // 3. Крупные показатели: уровень, изменение за сутки, прогноз 24ч, объекты повышенного риска
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        title = "Уровень воды (факт)",
                        value = "742 см",
                        trend = "+8 см/сут • до порога 8 см",
                        statusColor = RiskAttentionAmber,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Динамика за 24 ч",
                        value = "+8 см",
                        trend = "Интенсивность умеренная",
                        statusColor = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        title = "Прогноз на 24 часа",
                        value = "751 см",
                        trend = "Переход в зону Высокий риск",
                        statusColor = RiskHighOrange,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Объекты повыш. риска",
                        value = "${state.attentionObjects.size} из ${state.allObjects.size}",
                        trend = "1 дамба, 1 дорога, 1 сектор",
                        statusColor = RiskHighOrange,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 4. Компактный и хорошо читаемый график прогноза
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkSurfaceCard)
                    .border(1.dp, DarkSurfaceCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ПРОГНОЗ УРОВНЯ ВОДЫ (5 СУТОК)",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Створ Петропавловск (см над нулем поста)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = "Опасная: 800 см",
                        color = RiskCriticalRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Canvas график
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    val width = size.width
                    val height = size.height

                    val points = state.forecastPoints
                    if (points.isEmpty()) return@Canvas

                    val minVal = 700f
                    val maxVal = 810f
                    val range = maxVal - minVal

                    fun getY(v: Float) = height - ((v - minVal) / range * height)

                    // Горизонтальные линии порогов
                    val warningY = getY(750f)
                    val dangerY = getY(800f)

                    // 750 см (Предупредительный)
                    drawLine(
                        color = Color(0x66F59E0B),
                        start = Offset(0f, warningY),
                        end = Offset(width, warningY),
                        strokeWidth = 2f
                    )

                    // 800 см (Опасный)
                    drawLine(
                        color = Color(0x66EF4444),
                        start = Offset(0f, dangerY),
                        end = Offset(width, dangerY),
                        strokeWidth = 2f
                    )

                    val stepX = width / (points.size - 1)
                    val linePath = Path()

                    points.forEachIndexed { i, p ->
                        val px = i * stepX
                        val py = getY(p.valueCm.toFloat())

                        if (i == 0) {
                            linePath.moveTo(px, py)
                        } else {
                            linePath.lineTo(px, py)
                        }

                        // Точки
                        drawCircle(
                            color = if (p.isForecast) BrandCyanLight else Color.White,
                            radius = if (i == 3) 6f else 4f,
                            center = Offset(px, py)
                        )
                    }

                    drawPath(
                        path = linePath,
                        color = BrandCyanPrimary,
                        style = Stroke(width = 3.5f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    state.forecastPoints.filterIndexed { idx, _ -> idx % 2 == 0 }.forEach { p ->
                        Text(
                            text = "${p.day}\n${p.valueCm} см",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // 5. Раздел «Требуют внимания»
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ТРЕБУЮТ ВНИМАНИЯ (${state.attentionObjects.size})",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Только риск > Норма",
                    color = TextTertiary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Карточки проблемных объектов
        items(state.attentionObjects) { obj ->
            AttentionObjectCard(
                obj = obj,
                onClick = { onSelectObject(obj.id) },
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

/**
 * Карточка списка: только название, тип объекта, ключевой показатель и статус риска.
 */
@Composable
fun AttentionObjectCard(
    obj: HydroObject,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurfaceCard)
            .border(1.5.dp, getRiskBorderColor(obj.status), RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = obj.name,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = obj.type,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            RiskBadge(status = obj.status)
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "${obj.keyMetric}:",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = obj.keyValue,
                    color = getRiskColor(obj.status),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Text(
                text = "Подробнее →",
                color = BrandCyanLight,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
