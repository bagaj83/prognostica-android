package kz.prognostika.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kz.prognostika.app.ui.components.DemoHeader
import kz.prognostika.app.ui.theme.*
import kz.prognostika.app.ui.viewmodel.PrognostikaUiState

@Composable
fun MoreScreen(
    state: PrognostikaUiState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            DemoHeader(
                title = "О СИСТЕМЕ",
                subtitle = "Архитектура и регламенты",
                updatedAt = state.metadata.updatedAt
            )
        }

        // Предупреждение DEMO
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF451A03))
                    .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "ДЕМОНСТРАЦИОННЫЙ РЕЖИМ (MVP 0.2)",
                    color = Color(0xFFFDE68A),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = state.metadata.disclaimer,
                    color = Color(0xFFFEF3C7),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Базовый принцип системы
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DarkSurfaceCard)
                    .border(1.dp, DarkSurfaceCardBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "БАЗОВЫЙ ПРИНЦИП ПРЕДСТАВЛЕНИЯ",
                    color = BrandCyanLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "данные → событие → территория → объект → последствия → риск → рекомендуемое действие",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Система не является просто картой или набором графиков. Главный объект представления информации — оперативный риск для конкретной территории или объекта и его динамика во времени.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Источники данных
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DarkSurfaceCard)
                    .border(1.dp, DarkSurfaceCardBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "ПОДКЛЮЧАЕМЫЕ ИСТОЧНИКИ ДАННЫХ",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                val sources = listOf(
                    "РГП «Казгидромет»" to "Гидропосты, уровни, расходы, снегозапасы, метеопрогнозы",
                    "Комитет по водным ресурсам" to "Телеметрия Сергеевского и Петропавловского гидроузлов",
                    "МЧС РК (ДЧС СКО)" to "Паспорта защитных дамб, ПВР, оперативные сводки",
                    "АО «НК «Қазақстан Ғарыш Сапары»" to "Спутниковый радарный мониторинг зон разлива рек",
                    "Местные исполнительные органы" to "Инфраструктура дорог, мостов и жилого сектора"
                )
                sources.forEach { (src, desc) ->
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(text = "• $src", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = desc, color = TextTertiary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
