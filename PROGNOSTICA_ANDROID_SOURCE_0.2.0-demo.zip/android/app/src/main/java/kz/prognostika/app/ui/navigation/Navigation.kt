package kz.prognostika.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Overview : Screen("overview", "Обстановка", Icons.Default.Assessment)
    object Map : Screen("map", "Карта", Icons.Default.Map)
    object Objects : Screen("objects", "Объекты", Icons.Default.List)
    object Alerts : Screen("alerts", "События", Icons.Default.Notifications)
    object More : Screen("more", "Ещё", Icons.Default.MoreHoriz)
    
    object ObjectDetail : Screen("object_detail/{objectId}", "Карточка объекта", Icons.Default.Assessment) {
        fun createRoute(objectId: String) = "object_detail/$objectId"
    }
}

val bottomNavItems = listOf(
    Screen.Overview,
    Screen.Map,
    Screen.Objects,
    Screen.Alerts,
    Screen.More
)
