package kz.prognostika.app.data.model

/**
 * Уровни риска системы «Прогностика»
 * Принцип: цвет является лишь вспомогательным индикатором,
 * обязательна однозначная текстовая расшифровка.
 */
enum class RiskStatus(
    val titleRu: String,
    val description: String,
    val priorityLevel: Int
) {
    NORMAL(
        titleRu = "Норма",
        description = "Гидрологические показатели в пределах среднемноголетних сезонных норм",
        priorityLevel = 0
    ),
    ATTENTION(
        titleRu = "Внимание",
        description = "Приближение показателей к контрольным предупредительным отметкам",
        priorityLevel = 1
    ),
    HIGH(
        titleRu = "Высокий риск",
        description = "Превышение предупредительного уровня, высокая вероятность затопления пойменных участков",
        priorityLevel = 2
    ),
    CRITICAL(
        titleRu = "Критический риск",
        description = "Превышение опасных отметок, угроза затопления населенных пунктов и инфраструктуры",
        priorityLevel = 3
    );

    val isAttentionOrHigher: Boolean
        get() = this != NORMAL
}

/**
 * Обоснование оценки риска (Evidence Chain)
 * Принцип: данные -> событие -> территория -> объект -> последствия -> риск -> действие
 */
data class EvidenceStep(
    val source: String,
    val data: String,
    val calculation: String,
    val risk: String,
    val recommendation: String,
    val timestamp: String? = null,
    val modelDetails: String? = null
)

/**
 * Инженерный параметр контролируемого объекта
 */
data class ObjectParameter(
    val name: String,
    val value: String,
    val unit: String? = null,
    val source: String,
    val status: String = "normal", // normal, warning, danger
    val lastUpdated: String? = null
)

/**
 * Историческая запись журнала объекта
 */
data class ObjectHistoryEntry(
    val date: String,
    val title: String,
    val type: String, // info, warning, high
    val details: String
)

/**
 * Координаты объекта для карты/схемы
 */
data class LocationPoint(
    val name: String,
    val xPercent: Float, // [0..100] для векторной схемы
    val yPercent: Float, // [0..100]
    val coordinatesText: String? = null
)

/**
 * Модель контролируемого объекта гидротехнической системы
 */
data class HydroObject(
    val id: String,
    val name: String,
    val type: String,
    val category: String,
    val status: RiskStatus,
    val keyMetric: String,
    val keyValue: String,
    val trend: String,
    val forecast: String,
    val recommendation: String,
    val location: LocationPoint,
    val hazardLevel: String,
    val probability: String, // Низкая, Средняя, Высокая
    val consequences: String, // Незначительные, Умеренные, Тяжёлые
    val parameters: List<ObjectParameter>,
    val evidence: EvidenceStep,
    val history: List<ObjectHistoryEntry> = emptyList()
)

/**
 * Точка гидрологического ряда/прогноза
 */
data class WaterForecastPoint(
    val day: String,
    val date: String,
    val valueCm: Int,
    val isForecast: Boolean,
    val uncertaintyCm: Int, // погрешность +/- см
    val status: RiskStatus
)

/**
 * Оперативное событие / предупреждение
 */
data class AlertEvent(
    val id: String,
    val priority: RiskStatus,
    val objectId: String,
    val objectName: String,
    val title: String,
    val description: String,
    val consequences: String,
    val time: String,
    val action: String
)

/**
 * Метаданные текущего сеанса и демонстрационного режима
 */
data class SystemMetadata(
    val mode: String = "DEMO",
    val version: String = "MVP 0.2 / DEMO",
    val updatedAt: String = "16.09.2026 09:00",
    val disclaimer: String = "Демонстрационный режим. Все числовые значения являются тестовыми и не являются фактическими гидрологическими наблюдениями или инженерными заключениями.",
    val region: String = "г. Петропавловск и бассейн реки Есиль (пилотный контур)",
    val overallRisk: RiskStatus = RiskStatus.ATTENTION,
    val normalMaxCm: Int = 700,
    val warningLevelCm: Int = 750,
    val criticalLevelCm: Int = 800
)
