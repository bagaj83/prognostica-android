package kz.prognostika.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kz.prognostika.app.data.model.HydroObject
import kz.prognostika.app.data.model.RiskStatus
import kz.prognostika.app.ui.components.DemoHeader
import kz.prognostika.app.ui.components.RiskBadge
import kz.prognostika.app.ui.theme.*
import kz.prognostika.app.ui.viewmodel.PrognostikaUiState

@Composable
fun ObjectsScreen(
    state: PrognostikaUiState,
    onSelectObject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("Все") }
    var selectedStatus by remember { mutableStateOf<RiskStatus?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val categories = listOf("Все") + state.allObjects.map { it.category }.distinct()

    val filteredObjects = state.allObjects.filter { obj ->
        (selectedCategory == "Все" || obj.category == selectedCategory) &&
        (selectedStatus == null || obj.status == selectedStatus) &&
        (searchQuery.isBlank() || obj.name.contains(searchQuery, ignoreCase = true) || obj.type.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        DemoHeader(
            title = "ОБЪЕКТЫ",
            subtitle = "Реестр контролируемых объектов (${filteredObjects.size})",
            updatedAt = state.metadata.updatedAt
        )

        // Поле поиска
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Поиск объекта по названию...", color = TextTertiary, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkSurfaceCard,
                unfocusedContainerColor = DarkSurfaceCard,
                focusedBorderColor = BrandCyanPrimary,
                unfocusedBorderColor = DarkSurfaceCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp)
        )

        // Горизонтальный фильтр категорий
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) BrandCyanPrimary else DarkSurfaceCard)
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cat,
                        color = if (isSelected) Color.White else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        // Список объектов (на карточке только название, тип, показатель и статус)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredObjects) { obj ->
                AttentionObjectCard(
                    obj = obj,
                    onClick = { onSelectObject(obj.id) }
                )
            }
        }
    }
}
