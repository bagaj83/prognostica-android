# Исходный код Android-приложения «Прогностика»

Данная директория содержит полный проект нативного мобильного Android-приложения **«Прогностика»** на языке **Kotlin** с использованием декларативного UI-фреймворка **Jetpack Compose** и дизайн-системы **Material 3**.

---

## Архитектура проекта

- **Язык**: Kotlin 1.9.22+
- **Интерфейс**: Jetpack Compose (BOM 2024.02.00) + Material 3
- **Архитектурный паттерн**: Clean Architecture + MVVM + Unidirectional Data Flow (UDF)
- **Управление состоянием**: Kotlin Coroutines + `StateFlow`
- **Навигация**: `androidx.navigation:navigation-compose`
- **Целевые SDK**: `minSdk = 26` (Android 8.0 Oreo), `targetSdk = 34` (Android 14)

---

## Структура каталогов

```
android/
├── build.gradle.kts                // Корневой скрипт сборки Gradle
├── settings.gradle.kts             // Настройки проекта и репозиториев
├── gradle.properties               // JVM и AndroidX параметры
├── README.md                       // Настоящая инструкция
└── app/
    ├── build.gradle.kts            // Скрипт сборки модуля app (зависимости Compose, Coroutines)
    └── src/main/
        ├── AndroidManifest.xml     // Манифест приложения с разрешениями
        └── java/kz/prognostika/app/
            ├── MainActivity.kt     // Точка входа Activity с поддержкой Edge-to-Edge
            ├── PrognostikaApp.kt   // Главный Scaffold с нижней навигацией (5 вкладок)
            ├── data/
            │   ├── model/
            │   │   └── Models.kt   // Модели: HydroObject, RiskStatus, WaterForecastPoint, AlertEvent
            │   └── repository/
            │       └── PrognostikaRepository.kt // Репозиторий с пилотными объектами Есиль/Петропавловск
            └── ui/
                ├── components/
                │   └── CommonComponents.kt      // Карточки, бейджи риска, шапка с DEMO
                ├── navigation/
                │   └── Navigation.kt            // Маршруты и граф навигации
                ├── theme/
                │   ├── Color.kt                 // Цветовая гамма, цвета рисков
                │   └── Theme.kt                 // Material 3 Dark Palette
                ├── viewmodel/
                │   └── PrognostikaViewModel.kt  // StateFlow UI-состояния
                └── screens/
                    ├── OverviewScreen.kt        // Главный экран «Обстановка» (риски, 24ч прогноз, график)
                    ├── ObjectsScreen.kt         // Реестр объектов с фильтрами по категориям
                    ├── ObjectDetailScreen.kt    // Карточка (Состояние, Показатели, Прогноз, Риск, Основание, Действие)
                    ├── MapScreen.kt             // Схема бассейна реки Есиль с отметками объектов
                    ├── AlertsScreen.kt          // Оперативный журнал предупреждений
                    └── MoreScreen.kt            // О системе, методология, источники данных
```

---

## Запуск в Android Studio

1. Откройте **Android Studio** (версии Hedgehog, Iguana или Ladybug).
2. Выберите **File -> Open...** и укажите папку `/android`.
3. Дождитесь автоматической синхронизации **Gradle Sync**.
4. Подключите реальное Android-устройство по USB или запустите виртуальный эмулятор (Pixel 7 / Android 14).
5. Нажмите кнопку **Run ▶ (Shift + F10)**.
